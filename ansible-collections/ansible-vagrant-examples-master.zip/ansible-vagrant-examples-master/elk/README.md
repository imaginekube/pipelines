# ELK Example

This example has been moved to the [Ansible for DevOps repository](https://github.com/geerlingguy/ansible-for-devops).
